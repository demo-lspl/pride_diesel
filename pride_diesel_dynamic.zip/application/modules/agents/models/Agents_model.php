<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Agents_model extends MY_Model {
	protected $table = 'users';
	
	
	public function __construct(){
		parent::__construct();
	}
	
	public $rules = array( 
					'company_name' => array('field'=>'company_name', 'label'=>'Name', 'rules'=>'required|trim'), 
					'address' => array('field'=>'address', 'label'=>'Address', 'rules'=>'required|trim'),
					'company_email' => array('field'=>'company_email', 'label'=>'Email Address', 'rules'=>'required|trim|valid_email'),
					'company_password' => array('field'=>'company_password', 'label'=>'Password', 'rules'=>'trim|matches[confirm_company_password]'),
					'confirm_company_password' => array('field'=>'confirm_company_password', 'label'=>'Confirm Password', 'rules'=>'trim'));			
	
	public function get_new(){
		$company = new stdClass();
		$company->company_name 		= '';
		$company->address 			= '';
		$company->city 				= '';
		$company->province 			= '';
		$company->postal_code 		= '';
		$company->company_email 	= '';
		$company->role 				= 'employee';
		$company->last_activity 	= '';
		$company->status 			= 0;
		$company->company_password 	= '';
		
		return $company;
	}
	
	public function get_users($where = null){
		$this->db->where('role =', 'employee');
		$this->db->where('company_email !=', 'admin@gmail.com');
		if(!empty($where)){
			$this->db->like('company_name', $where);
		}
		$this->db->order_by('id', 'DESC');
		$getUsers = $this->db->get($this->table);
		//pre($this->db->last_query());
		return $getUsers->result();
	}
	
    public function get_pagination($limit, $offset, $where = null)
    {
		$offset = ($offset-1) * $limit;	
		if(!empty($where)){
			$this->db->like('company_name', $where);
		}
		$this->db->where('role =', 'employee');
		$this->db->where('company_email !=', 'admin@gmail.com');
        $this->db->limit($limit, $offset);
		$this->db->order_by('id','DESC');
        $query = $this->db->get($this->table);
        
        if(!is_object($query))
        {
            echo $this->db->last_query();
            exit();
        }
		//pre($this->db->last_query());
        if ($query->num_rows() > 0)
			//print_r($query->result());
            return $query->result();
            
        return array();
    }
	
	public function create_user($data, $id=null){
		if($id){
			$this->db->set($data);
			$this->db->where('id', $id);
			$this->db->update($this->table);
		}else{
			$this->db->insert($this->table, $data);
			$id = $this->db->insert_id();			
		}
		return $id;
	}
	
	public function get_by_id($id = null){
		$this->db->where('id', $id);
		$values = $this->db->get($this->table)->row();
		return $values;	
	}	

	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete($this->table);
		return true;
	}

	#Accounts Permission
	public function get_data($table = '' , $where = array()) {
		$this->tablename = $table?$table:$this->tablename;
		$this->db->select('*'); 
		$this->db->from($this->tablename);
		$this->db->where($where);
		$qry = $this->db->get();
		#echo $dynamicdb->last_query();
		$result = $qry->result_array();			
		return $result;
	}

	public function save_user_permissions($data) {
	$this->db->insert('permissions', $data);
	}	

	function update_user_permissions($user_id, $id, $permissions_data) {
		
        $this->db->where('user_id', $user_id);
        $this->db->where('sub_module_id', $id);
        $q = $this->db->get('permissions');
		//echo $this->db->last_query();die();
        if ($q->num_rows() > 0) {
			
            $this->db->where('user_id', $user_id);
            $this->db->where('sub_module_id', $id);
            $this->db->update('permissions', $permissions_data);
        } else {
			$this->db->insert('permissions', $permissions_data);
            
        }
        return true;
    }  
	  
	function fetch_user_premissions_by_id($id, $where = array()) {
      //  $this->db->select('sm.sub_module_name as sub_module_name,sm.id as sub_module_id,p.id ,p.is_all as is_all,p.is_view as is_view,p.is_add as is_add,p.is_edit as is_edit,p.is_delete as is_delete,p.is_validate as is_validate ,p.is_validate_purchase_budget_limit as is_validate_purchase_budget_limit');
	  
	  
        $this->db->select('sm.sub_module_name as sub_module_name,sm.id as sub_module_id,p.id ,p.is_view as is_view,p.is_add as is_add,p.is_edit as is_edit,p.is_delete as is_delete');
        $this->db->from('sub_module sm');
        $this->db->join('permissions p', 'sm.id = p.sub_module_id and p.user_id="' . $id . '"', 'left');
        $this->db->where($where);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }  
	  
	 public function get_data_byId($table ,$field, $id) {
		
		$this->db->select('*');  
		$this->db->from($table);
		$this->db->where($table.'.'.$field, $id);
		$qry = $this->db->get();
		$result = $qry->row();	
		return $result;
	} 	
}