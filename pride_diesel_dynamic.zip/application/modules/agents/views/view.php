<style>
   .col-md-3,.col-md-6{float:left;}
   .form-group {
    margin-bottom: 1rem;
    clear: both;
}
</style>

<div class="col-md-12 col-sm-12 col-xs-12 form-group">
					<input type="hidden" name="id" value="<?php if(!empty($user_dtl)) echo $user_dtl->id; ?>">
					<div class="col-md-12 col-sm-12 col-xs-12 form-group">	
						<div class="col-md-12 col-sm-12 col-xs-12 form-group">
						<?php if($this->session->flashdata("success")){?>
					<div class="alert alert-success">      
						<?php echo $this->session->flashdata("success")?>
					</div>
					    <?php } ?>	
							<div class=" panel-default">
								        <?php 
										   if($_SESSION['userdata']->role == 'admin' ) { ?>
											  <button type="button" class="btn btn-warning  float-right" data-toggle="modal" data-target=".bs-example-modal-lg-permissions">Permissions</button>
										<?php } ?>
											  <br />
										<div class="x_content">
											<div class="" role="tabpanel" data-example-id="togglable-tabs">
												<!--<ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
													<li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Information</a>
													</li>
													<li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Mailing Details</a>
													</li>
													
													<li role="presentation" class=""><a href="#tab_content4" role="tab" id="profile-tab3" data-toggle="tab" aria-expanded="false">Company Details</a>
													</li>
													<li role="presentation" class=""><a href="#tab_content5" role="tab" id="profile-tab4" data-toggle="tab" aria-expanded="false">Contact Person Details</a>
													</li>
												</ul>-->
												<div id="myTabContent" class="tab-content">
												   <div class="row">
													  <!--<h3 class="Material-head">Contact Details <hr></h3>-->
														<div class="col-md-6 col-xs-12 col-sm-12 vertical-border ">
																<!--tr>
																      <th scope="row">Parent Ledger</th>
																	  <td><?php //if(!empty($ledger)) echo $ledger->type; ?></td>
																</tr-->
																	
																	<div class="item form-group">
																	  <label class=" col-md-3 col-sm-3 col-xs-5" scope="row">User Name </label>
																	  <div class="col-md-6 col-sm-6 col-xs-7"><?php if(!empty($user_dtl)) echo $user_dtl->company_name; ?></div>
																	</div>
																	
																	<div class="item form-group">
																	  <label class=" col-md-3 col-sm-3 col-xs-5" scope="row">Email</label>
																	  <div class="col-md-6 col-sm-6 col-xs-7"><?php if(!empty($user_dtl)) echo $user_dtl->company_email; ?></div>
																	</div>
																
																	
																	
																 
														</div>
														
														
												</div>
													<div class="bottom-bdr"></div>
													
												</div>
											</div>
																			
								</div>
							</div>
						</div>
					</div>
		
			<div class="col-md-12 col-sm-12 col-xs-12 form-group">
				<div class="form-group">
					<div class="modal-footer">
						<button onclick="goBack()" class="btn btn-default" >Back</button>
					</div>
				</div>
			</div>
			
			
			
<!-- ------------------------------------------------- Permissions Modal -------------------------------------------- -->

<?php
	$permissionsArray = array();
        $i                             = 0;

		if($this->uri->segment(3) != FALSE){
			$id = $this->uri->segment(3);
		}
		
		 foreach ($module as $parentModule) {
            $permissionsArray[$i]               = $parentModule;
            $sub_modules                        = $this->agents_model->get_data('sub_module', array('modules_id' => $parentModule['id']));
            $permissionsArray[$i]['sub_module'] = $sub_modules;
            $y                                  = 0;
            #pre($sub_modules);         
            foreach ($sub_modules as $sub_module) {
                $permissions = $this->agents_model->fetch_user_premissions_by_id($id, array('p.sub_module_id' => $sub_module['id'],'p.user_id' => $id));
                #pre($permissions);
                $permissionsArray[$i]['sub_module'][$y]['permissions'] = $permissions;
                $y++;
            }
            $i++;
        }
		
		          
 ?>




   <div class="modal fade bs-example-modal-lg-permissions" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-large">
         <div class="modal-content">
            <form action="<?php echo base_url();?>agents/save_permission" method="post" enctype="multipart/form-data" id="permissionForm">
			<?php 
			if($this->uri->segment(3) != FALSE){
				$user_id = $this->uri->segment(3);
			}
			?>
               <input type="hidden" name="id" value="<?php echo $user_id; ?>">			
               <div class="modal-header">
			       <h4 class="modal-title" id="myModalLabel">Give Permissions</h4> 
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                  </button>
                 
               </div>
               <div class="modal-body">
                  <div class="tbl-header">
                       
                     <table class="table table-striped jambo_table bulk_action">
                        <thead>
                           <tr>
                              <th width="14%"> Modules </th>
                              <!--th width="14%">Is_All</th-->
                              <th width="14%">Is_Create</th>
                              <th width="14%">Is_Edit</th>
                              <th width="14%">Is_Delete</th>
                              <th width="14%">Is_View</th>
                              <!--th width="14%">Is_Validate</th-->
                             <!-- <th width="15%">Is_Validate_Purchase_Budget_Limit</th>-->
                           </tr>
                        </thead>
                        <tbody>
                        </tbody>
                     </table>
                  </div>
				    
                  <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                 
                    
                     <?php if(!empty($permissionsArray)){
                       # pre($);
                        $i = 0; 
                        	foreach($permissionsArray as $pa){
								
								?>
                     <div class="panel  my-div-cs">

                        <a class="panel-heading" role="tab" id="<?php echo $pa['id']; ?>" data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo $pa['id']; ?>" aria-expanded="true" aria-controls="collapseOne">
                           <h4 class="panel-title" style="color: black;font-size: 19px;font-weight: bold;"><?php echo ucwords($pa['module_name']);?></h4>
                        </a>

                        <div id="collapse_<?php echo $pa['id']; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="<?php echo $pa['id']; ?>">
                           <div class="panel-body">
                              <table class="table table-striped jambo_table bulk_action" >
                                              
                                    <?php if(!empty($pa['sub_module'])) {
                                       foreach($pa['sub_module'] as $pasm){
										//pre($pasm);
										
                                       ?>													
                                    <tr>
                                       <td width="15%"><strong><i><?php if(!empty($pasm)) echo ucwords($pasm['sub_module_name']);  ?></i></strong></td>
                                       
									    <!--td><input type="checkbox" class="all permissions_cls" name="<?php if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_all" value="1" <?php if(!empty($pasm['permissions']) && @$pasm['permissions'][0]->is_all == 1) { echo 'checked';} ?>></td-->
									   <!--name="<?php //if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_add" -->
                                       <td><input type="checkbox" class="add permissions_cls" name="<?php if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_add" value='1'  <?php if(!empty($pasm['permissions']) && $pasm['permissions'][0]->is_add == 1) { echo 'checked';} ?>></td>
                                       <td><input  type="checkbox" class="edit permissions_cls" name="<?php if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_edit" value='1' <?php if(!empty($pasm['permissions']) && $pasm['permissions'][0]->is_edit == 1) { echo 'checked';} ?> > </td>
                                       <td><input type="checkbox" class="delete permissions_cls" name="<?php if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_delete" value='1' <?php if(!empty($pasm['permissions']) && $pasm['permissions'][0]->is_delete == 1) { echo 'checked';} ?>></td>
                                       <td><input type="checkbox" class="view permissions_cls" name="<?php if(!empty($pasm['permissions'])) echo $pasm['permissions'][0]->sub_module_id; ?>_view" value='1' <?php if(!empty($pasm['permissions']) && $pasm['permissions'][0]->is_view == 1) { echo 'checked';} ?>></td>
                                     
                                    </tr>
                                    <?php }} ?>														
                                
                              </table>
                           </div>
                        </div>
                     </div>
                     <?php $i++; }}?>	
                     <!-- end of accordion -->
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <input type="submit" value="save" class="btn btn-warning">	
               </div>
            </form>
         </div>
      </div>
   </div>		