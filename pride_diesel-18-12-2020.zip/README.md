# pride_diesel
 Pride Diesel
